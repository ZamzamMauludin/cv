<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>CV Zamzam mauludin</title>
  <meta name="description" content="simple CV example created with HTML and CSS">
  <meta name="author" content="Fly Nerd">
  <link rel="icon" href="./img/favicon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <div>
       <img src="./img/1.jpg" />
    </div>
    <h1>Dika Arief Sugiyatna</h1>
    <section>
       <p>Hai Nama saya ZAMZAM MAULDIN saya adalah seorang pelajar di SEKOLAH MENENGAH KEJURUAN AL FALAH DAGO BANDUNG, saya berusia 18 tahun lahir di BANDUNG 4 September 2001, Hobi saya adalah Berenang dan memelihara hewan, Saya beralamatkan di Jl.Cisitu lama rt10/rw12 No.58 Bandung Jawa Barat,</p>
      <a href="https://www.facebook.com/flynerdpl/" target="_blank">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="https://www.twitter.com/flynerdpl/" target="_blank">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="https://github.com/ritaly" target="_blank">
        <i class="fab fa-github-alt"></i>
      </a>
      <a href="https://www.instagram.com/flynerdpl/" target="_blank">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="https://www.linkedin.com/in/ritalyczywek/" target="_blank">
        <i class="fab fa-linkedin-in"></i>
      </a>
    </section>
  </header>
  <main>
    <section>
      <h3>Indentitas Lengkap Saya</h3>
      <article class='course'>
        <div class='title'>
          <h4>Nama</h4>
        </div>
        <div class="descrition">
          <p>Zamzam mauludin</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Tempat Tanggal Lahir</h4>
        </div>
        <div class="descrition">
          <p>Bandung, 4 September 2001</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Alamat</h4>
        </div>
        <div class="descrition">
          <p>Jl.Cisitu lama Dalam Rt.10 Rw.12 Kelurahan Dago Kecamatan Coblong Kota Bandung Jawa Barat</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Jenis Kelamin</h4>
        </div>
        <div class="descrition">
          <p>Laki Laki</p>
        </div>
      </article>
      <article class='course'>
        <div class='title'>
          <h4>Alamameter</h4>
        </div>
        <div class="descrition">
          <p>Institut Teknologi Bandung</p>
        </div>
      </article>
    </section>
    <section>
      <h3>Skills</h3>
      <div class='skills'>
        <div class='column'>
          <h4>Good knowledge</h4>
          <ul>
            <li>HTML5</li>
            <li>CSS</li>
            <li>JavaScript ES5/6</li>
            <li>SQL</li>
          </ul>
        </div>
        <div class='column'>
          <h4>Basic knowledge</h4>
          <ul>
            <li>jQuery</li>
            <li>NodeJS</li>
            <li>MongoDB</li>
            <li>Django</li>
          </ul>
        </div>
        <div>
          <h4>Bahasa</h4>
          <p> Indonesia - Bahasa Formal</p>
          <p> Sunda - Bahasa Sapopoe</p>
          
        </div>
      </div>
    </section>

    <section>
      <h3>Sekolah</h3>
      <article>
        <div class='school'>
          <span>2007-2013</span> <strong>Sdn Cisitu Bandung</strong>
        </div>
        <div class="descrition">
          Lulusan baik
        </div>
      </article>
      <article>
        <div class='school'>
          <span>2014-2017</span> <strong>Smp Al Falah Dago Bandung</strong>
        </div>
        <div>
          Lulusan Terbaik
        </div>
      </article>
      <article>
        <div class='school'>
          <span>2017-2020</span> <strong>Smk Al Falah Dago Bandung</strong>
        </div>
        <div class="descrition">
          Summer Cumlaude
        </div>
      </article>
    </section>
    <section>
      <h3>Praktik Kerja Lapangan</h3>
      <article>
        <div class='Praktik Kerja Lapangan'>
          <span>04.2019 - 06.2019</span> <strong>Polsek coblong</strong><br> <strong>Jabatan:</strong> KA sium coblong </div> <div>
            
          </ul>
        </div>
      </article>
    </section>
  </main>
  <footer>
    <p>Created by: Zamzam mauludin</a> / 2019 </p>
  </footer>
</body>
</html>
